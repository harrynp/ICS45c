//Harry Pham 79422112
#include "FwdStrategy1.hpp"

FwdStrategy1::FwdStrategy1()
{
}

bool FwdStrategy1::forward(Message &msg) const
{
	return true;
}