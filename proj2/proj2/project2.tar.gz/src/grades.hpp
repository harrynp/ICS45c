//Harry Pham 79422112
#ifndef GRADES_HPP
#define GRADES_HPP

Graded_Artifacts grades(const unsigned int &number_of_graded_artifacts);

void calculate_total_score(Student &student, const Graded_Artifacts &artifacts, const unsigned int &number_of_graded_artifacts);

#endif // GRADES_HPP