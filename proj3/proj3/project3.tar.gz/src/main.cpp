//Harry Pham 79422112

#include "UI.hpp"

int main(){
	UI ui = UI();
	ui.input();
}