//Harry Pham 79422112
#include "FwdStrategy5.hpp"

FwdStrategy5::FwdStrategy5()
{
}

bool FwdStrategy5::forward(Message &msg) const
{
	return false;
}