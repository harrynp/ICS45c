//Harry Pham 79422112
#include "SendStrategy1.hpp"

SendStrategy1::SendStrategy1()
{
}

std::list<std::string> SendStrategy1::forward(std::list<std::string> &contactlist, Message &msg) const
{
	return contactlist;
}